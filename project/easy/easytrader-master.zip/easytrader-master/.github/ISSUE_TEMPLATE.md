## env

OS: win / mac / linux
PYTHON_VERSION: 3.x
EASYTRADER_VERSION: 0.xx.xx

## problem

## how to repeat



